package com.example.portalberita;

// Mengimpor komponen dasar Android untuk layar dan dialog.
import android.app.Activity;
import android.app.AlertDialog;
// Mengimpor kelas untuk mengatur warna dan gaya tulisan.
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
// Mengimpor alat untuk mengirim pembaruan kembali ke UI utama.
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
// Mengimpor kelas tampilan dasar dan layout.
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
// Mengimpor parser JSON bawaan Android untuk membaca jawaban server.
import org.json.JSONArray;
import org.json.JSONObject;
// Mengimpor alat baca data jaringan dan alamat API.
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
// Mengimpor koleksi dan thread latar belakang.
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Activity adalah satu layar yang dikelola oleh Android.
public class MainActivity extends Activity {
    // Emulator Android memakai alamat khusus ini untuk mengakses komputer host.
    private static final String API_URL = "http://192.168.1.2:8000/api/news/";

    // Menyimpan berita yang sudah diterima dari server.
    private final ArrayList<Article> articles = new ArrayList<>();
    // Menjalankan permintaan jaringan di luar thread tampilan agar aplikasi tidak macet.
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    // Mengirim hasil pekerjaan thread latar belakang ke thread tampilan Android.
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    // Adapter menghubungkan data berita dengan baris-baris ListView.
    private NewsAdapter adapter;
    // Label ini menampilkan status memuat, jumlah berita, atau pesan kesalahan.
    private TextView statusView;

    // Dipanggil Android saat layar aplikasi pertama kali dibuat.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Menjalankan inisialisasi Activity dari kelas induk.
        super.onCreate(savedInstanceState);

        // Membuat layout utama yang menyusun komponen dari atas ke bawah.
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(dp(20), dp(20), dp(20), dp(8));

        // Membuat baris judul dan tombol muat ulang.
        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setOrientation(LinearLayout.HORIZONTAL);

        // Menampilkan nama halaman portal berita.
        TextView titleView = new TextView(this);
        titleView.setText("Kabar Hari Ini");
        titleView.setTextColor(0xFF202020);
        titleView.setTextSize(26);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.addView(titleView, new LinearLayout.LayoutParams(0, dp(52), 1));

        // Tombol ini mengulangi permintaan berita saat disentuh.
        Button refreshButton = new Button(this);
        refreshButton.setText("Muat ulang");
        refreshButton.setOnClickListener(view -> loadArticles());
        heading.addView(refreshButton);
        screen.addView(heading);

        // Menyiapkan label status sebelum daftar berita ditampilkan.
        statusView = new TextView(this);
        statusView.setTextColor(0xFF666666);
        statusView.setTextSize(14);
        statusView.setPadding(0, dp(4), 0, dp(12));
        screen.addView(statusView);

        // ListView menampilkan berita dalam daftar yang dapat digulir.
        ListView articleList = new ListView(this);
        articleList.setDivider(new ColorDrawable(Color.LTGRAY));
        articleList.setDividerHeight(dp(1));
        adapter = new NewsAdapter();
        articleList.setAdapter(adapter);
        // Ketukan pada satu baris membuka isi lengkap berita tersebut.
        articleList.setOnItemClickListener((parent, view, position, id) -> showArticle(articles.get(position)));
        screen.addView(articleList, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        // Menjadikan layout buatan tadi sebagai tampilan Activity.
        setContentView(screen);
        // Mengambil berita pertama kali ketika layar dibuka.
        loadArticles();
    }

    // Meminta daftar berita dari API tanpa menghentikan tampilan.
    private void loadArticles() {
        statusView.setText("Memuat berita...");
        executor.execute(() -> {
            try {
                // fetchArticles melakukan koneksi dan parsing di thread latar belakang.
                ArrayList<Article> result = fetchArticles();
                // Semua perubahan komponen UI harus dilakukan di thread utama.
                mainHandler.post(() -> {
                    articles.clear();
                    articles.addAll(result);
                    adapter.notifyDataSetChanged();
                    statusView.setText(articles.isEmpty()
                            ? "Belum ada berita yang diterbitkan."
                            : articles.size() + " berita terbaru");
                });
            } catch (Exception exception) {
                // Menampilkan pesan aman dan ringkas bila server belum dapat dihubungi.
                mainHandler.post(() -> statusView.setText(
                        "Gagal memuat berita. Periksa server dan koneksi jaringan."));
            }
        });
    }

    // Mengunduh JSON dari server dan mengubah setiap objek menjadi Article.
    private ArrayList<Article> fetchArticles() throws Exception {
        // Membuka koneksi HTTP ke alamat endpoint yang sudah ditentukan.
        HttpURLConnection connection = (HttpURLConnection) new URL(API_URL).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);

        try {
            // Memastikan server menjawab dengan kode sukses HTTP 200.
            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw new IllegalStateException("HTTP " + responseCode);
            }

            // Membaca seluruh teks JSON dari badan respons HTTP.
            StringBuilder response = new StringBuilder();
            try (InputStream input = connection.getInputStream();
                 BufferedReader reader = new BufferedReader(
                         new InputStreamReader(input, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
            }

            // Mengambil array bernama articles sesuai format jawaban Django.
            JSONArray items = new JSONObject(response.toString()).getJSONArray("articles");
            ArrayList<Article> result = new ArrayList<>();
            // Mengubah setiap objek JSON menjadi objek Article untuk tampilan.
            for (int index = 0; index < items.length(); index++) {
                JSONObject item = items.getJSONObject(index);
                result.add(new Article(
                        item.optString("title", "Tanpa judul"),
                        item.optString("summary", ""),
                        item.optString("content", ""),
                        item.optString("author", "Redaksi"),
                        item.optString("category", "Umum"),
                    item.optString("published_at", ""),
                    item.optString("image_url", "")));
            }
            return result;
        } finally {
            // Menutup koneksi agar sumber daya jaringan dapat dipakai kembali.
            connection.disconnect();
        }
    }

    // Mengunduh thumbnail di thread latar belakang agar tampilan tetap responsif.
    private void loadImage(String imageUrl, ImageView imageView) {
        if (imageUrl.isEmpty()) {
            imageView.setVisibility(View.GONE);
            return;
        }

        imageView.setVisibility(View.VISIBLE);
        imageView.setTag(imageUrl);
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(imageUrl).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    throw new IllegalStateException("Gagal memuat gambar");
                }

                Bitmap bitmap = BitmapFactory.decodeStream(connection.getInputStream());
                if (bitmap == null) {
                    throw new IllegalStateException("Format gambar tidak didukung");
                }
                mainHandler.post(() -> {
                    if (imageUrl.equals(imageView.getTag())) {
                        imageView.setImageBitmap(bitmap);
                    }
                });
            } catch (Exception exception) {
                mainHandler.post(() -> {
                    if (imageUrl.equals(imageView.getTag())) {
                        imageView.setVisibility(View.GONE);
                    }
                });
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        });
    }

    // Menampilkan isi lengkap berita dalam dialog sederhana.
    private void showArticle(Article article) {
        String message = article.content + "\n\n" + article.category + " | " + article.author;
        new AlertDialog.Builder(this)
                .setTitle(article.title)
                .setMessage(message)
                .setPositiveButton("Tutup", null)
                .show();
    }

    // Mengubah ukuran dp menjadi piksel sesuai kepadatan layar perangkat.
    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    // Dipanggil saat layar ditutup agar pekerjaan jaringan dihentikan.
    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    // Model sederhana yang menyimpan nilai dari satu artikel berita.
    private static class Article {
        final String title;
        final String summary;
        final String content;
        final String author;
        final String category;
        final String publishedAt;
        final String imageUrl;

        // Mengisi semua properti artikel saat objek dibuat.
        Article(String title, String summary, String content, String author,
            String category, String publishedAt, String imageUrl) {
            this.title = title;
            this.summary = summary;
            this.content = content;
            this.author = author;
            this.category = category;
            this.publishedAt = publishedAt;
            this.imageUrl = imageUrl;
        }
    }

    // Adapter mengubah data Article menjadi tampilan satu baris berita.
    private class NewsAdapter extends BaseAdapter {
        // Memberi tahu ListView jumlah baris yang harus dibuat.
        @Override
        public int getCount() {
            return articles.size();
        }

        // Mengembalikan objek artikel untuk posisi baris tertentu.
        @Override
        public Object getItem(int position) {
            return articles.get(position);
        }

        // Menggunakan posisi daftar sebagai ID stabil sederhana untuk contoh ini.
        @Override
        public long getItemId(int position) {
            return position;
        }

        // Membuat baris kategori, judul, ringkasan, penulis, dan tanggal.
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(4), dp(14), dp(4), dp(14));

            // Mengambil artikel yang sesuai dengan baris yang sedang digambar.
            Article article = articles.get(position);

                // Membuat area gambar dan mengisinya dari URL yang diberikan API.
                ImageView imageView = new ImageView(MainActivity.this);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setBackgroundColor(0xFFE6E1DF);
                row.addView(imageView, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(180)));
                loadImage(article.imageUrl, imageView);

            // Menampilkan kategori sebagai label kecil berwarna aksen.
            TextView categoryView = new TextView(MainActivity.this);
            categoryView.setText(article.category.toUpperCase());
            categoryView.setTextColor(0xFFC44336);
            categoryView.setTextSize(12);
            categoryView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            row.addView(categoryView);

            // Menampilkan judul dengan ukuran dan ketebalan lebih menonjol.
            TextView titleView = new TextView(MainActivity.this);
            titleView.setText(article.title);
            titleView.setTextColor(0xFF202020);
            titleView.setTextSize(18);
            titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            titleView.setPadding(0, dp(4), 0, dp(4));
            row.addView(titleView);

            // Menampilkan ringkasan singkat di bawah judul berita.
            TextView summaryView = new TextView(MainActivity.this);
            summaryView.setText(article.summary);
            summaryView.setTextColor(0xFF555555);
            summaryView.setTextSize(14);
            row.addView(summaryView);

            // Menampilkan nama penulis dan waktu terbit dari API.
            TextView authorView = new TextView(MainActivity.this);
            authorView.setText(article.author + "  |  " + article.publishedAt);
            authorView.setTextColor(0xFF777777);
            authorView.setTextSize(12);
            authorView.setPadding(0, dp(8), 0, 0);
            row.addView(authorView);
            return row;
        }
    }
}