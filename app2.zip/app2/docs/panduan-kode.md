# Panduan Belajar KabarKita

Panduan ini mengikuti perjalanan satu berita dari database Django sampai tampil dan tersimpan di Android.

## Peta Proyek

### Backend Django

- `requirements.txt`: library Python yang diperlukan, yaitu Django, REST Framework, dan Pillow untuk membaca unggahan gambar.
- `server/manage.py`: titik masuk perintah seperti `runserver`, `migrate`, dan `seed_news`.
- `server/config/settings.py`: aplikasi terpasang, middleware, database, bahasa, host yang diizinkan, dan lokasi media.
- `server/config/urls.py`: menghubungkan path admin dan API; pada mode debug, path media diarahkan ke folder lokal.
- `server/config/wsgi.py`: menyediakan objek aplikasi yang dipanggil server WSGI.
- `server/news/apps.py`: metadata aplikasi `news` agar Django dapat mendaftarkannya.
- `server/news/models.py`: bentuk data kategori dan berita yang disimpan di SQLite.
- `server/news/serializers.py`: mengubah objek Django menjadi JSON yang menjadi kontrak data untuk Android.
- `server/news/views.py`: mengambil, mencari, memfilter, dan mengirim berita sebagai respons HTTP.
- `server/news/urls.py`: memetakan endpoint kategori serta daftar dan detail berita ke view.
- `server/news/admin.py`: menyiapkan daftar, filter, pencarian, dan formulir unggah di Django Admin.
- `server/news/management/commands/seed_news.py`: mengisi data contoh untuk latihan lokal.
- `server/news/migrations/0001_initial.py`: migration otomatis untuk tabel kategori dan berita.
- `server/news/migrations/0002_article_image.py`: migration otomatis yang menambahkan field file gambar ke berita.
- `server/db.sqlite3`: database lokal yang dibuat saat migration berjalan; file ini tidak disimpan ke Git.
- `server/media/articles/`: lokasi fisik file gambar yang diunggah melalui admin.

### Android dan Gradle

- `settings.gradle`: nama proyek, modul aplikasi, dan repository dependency Gradle.
- `build.gradle`: versi Android Gradle Plugin yang digunakan proyek.
- `gradle.properties`: opsi memori Gradle dan penggunaan AndroidX.
- `gradle/wrapper/gradle-wrapper.properties`: versi Gradle yang dipakai wrapper agar build konsisten.
- `gradlew` dan `gradlew.bat`: launcher wrapper untuk macOS/Linux dan Windows; `gradle-wrapper.jar` adalah implementasi wrapper.
- `app/build.gradle`: ID aplikasi, versi SDK Android, serta batas versi minimum dan sasaran.
- `app/src/main/AndroidManifest.xml`: izin jaringan dan pendaftaran Activity launcher.
- `app/src/main/res/values/styles.xml`: tema native serta warna system bar.
- `app/src/main/java/id/co/kabarkita/app/MainActivity.java`: layar, navigasi, pemanggilan API, pemuatan gambar, dan penyimpanan gambar lokal.
- `app/build/outputs/apk/debug/app-debug.apk`: APK debug yang dihasilkan Gradle; folder `build` dibuat ulang saat kompilasi.
- `.gitignore`: daftar database, media lokal, cache, dan hasil build yang tidak perlu masuk Git.

File `__init__.py` yang kosong hanya menandai folder Python sebagai package; file itu tidak memerlukan komentar tambahan.

## Alur Data Berita

1. `MainActivity.loadArticles()` menjalankan permintaan HTTP di executor agar proses jaringan tidak membekukan UI.
2. `request()` membaca respons API; `Article.fromJson()` mengubah setiap objek JSON menjadi objek Java.
3. `renderPage()` memilih tampilan berdasarkan `currentScreen`, lalu `articleRow()` menampilkan setiap berita.
4. Di server, URL `/api/articles/` memanggil view `articles()`. Parameter `category` dan `search` membatasi queryset sebelum `ArticleSerializer` menghasilkan JSON.

## Alur Penyimpanan Gambar

1. Admin memilih file pada formulir berita. `ImageField(upload_to="articles/")` menyimpan file di `server/media/articles/`; database hanya menyimpan nama/path file.
2. `MEDIA_ROOT` adalah folder di disk server, sedangkan `MEDIA_URL` adalah URL untuk membaca file. URL media lokal dilayani oleh Django hanya saat `DEBUG=True`.
3. `ArticleSerializer.get_image_url()` mengubah path file menjadi URL penuh berdasarkan alamat permintaan. Karena itu ponsel dapat mengakses alamat server yang sama.
4. Android memakai `BitmapFactory` untuk menampilkan gambar. Tombol **Unduh gambar** menyalin gambar ke `Pictures/KabarKita` memakai `MediaStore` pada Android 10+, tanpa meminta izin penyimpanan luas.
5. Pada Android lama, berkas disimpan ke direktori Pictures khusus aplikasi. Direktori ini lokal, tetapi tidak selalu terlihat di aplikasi galeri.

## Konsep yang Bisa Ditelusuri

- **Model dan migrasi:** ubah field pada `models.py`, lalu jalankan `py manage.py makemigrations` dan `py manage.py migrate`.
- **Serialisasi:** field JSON `image_url` tidak menyimpan isi gambar; field itu memberi klien lokasi file yang harus diminta secara terpisah.
- **Thread UI:** pekerjaan jaringan dilakukan di `ExecutorService`; perubahan tampilan dikirim kembali melalui `Handler` ke main thread.
- **Penyimpanan Android:** `IS_PENDING=1` membuat gambar belum terlihat saat masih ditulis. Setelah penulisan selesai, nilainya diubah menjadi `0` agar galeri dapat membacanya.
- **Konfigurasi produksi:** jangan memakai `DEBUG=True` untuk menyajikan media di server publik. Batasi ukuran/jenis unggahan dan sajikan media melalui web server atau object storage.

## Latihan

1. Tambahkan field `caption` pada model berita dan tampilkan di serializer serta halaman detail.
2. Tambahkan validasi ukuran maksimal dan tipe gambar sebelum file disimpan.
3. Buat unit test untuk filter kategori, pencarian, dan URL gambar.
4. Pindahkan alamat API dan `SECRET_KEY` ke konfigurasi environment sebelum deployment.