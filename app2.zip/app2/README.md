# KabarKita

Aplikasi berita sederhana dengan backend Django REST API dan klien Android native Java.
Panduan alur kode untuk mahasiswa tersedia di [docs/panduan-kode.md](docs/panduan-kode.md).

## Menjalankan API

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
cd server
py manage.py migrate
py manage.py seed_news
py manage.py runserver 0.0.0.0:8000
```

API tersedia di `http://127.0.0.1:8000/api/`.

- `GET /api/categories/`
- `GET /api/articles/`
- `GET /api/articles/?category=teknologi`
- `GET /api/articles/?search=ruang`
- `GET /api/articles/<slug>/`

Opsional: jalankan `py manage.py createsuperuser` untuk mengelola berita di `/admin/`.
Gambar yang diunggah melalui formulir berita admin disimpan di `server/media/articles/` dan disajikan lewat `/media/` saat `DEBUG=True`.

## Menjalankan Android

1. Buka folder proyek ini di Android Studio dan tunggu Gradle Sync selesai.
2. Jalankan API terlebih dahulu dengan perintah di atas.
3. Pilih emulator Android, lalu tekan Run. Emulator bawaan memakai `10.0.2.2` untuk mengakses server di komputer host.
4. Untuk perangkat fisik, ubah `API_BASE` pada `app/src/main/java/id/co/kabarkita/app/MainActivity.java` ke alamat IP komputer di jaringan lokal, lalu izinkan koneksi firewall pada port `8000`.

Untuk membuat APK, pilih **Build > Build APK(s)** di Android Studio. Hasil debug APK berada di `app/build/outputs/apk/debug/app-debug.apk`.