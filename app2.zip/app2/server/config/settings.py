from pathlib import Path


# Folder ini menjadi acuan lokasi database SQLite dan file unggahan.
BASE_DIR = Path(__file__).resolve().parent.parent
# Kunci dan mode debug ini hanya untuk belajar di komputer lokal.
SECRET_KEY = "development-only-change-this-before-deploying"
DEBUG = True
# Daftar host yang boleh mengakses server, termasuk alamat LAN perangkat Android.
ALLOWED_HOSTS = ["127.0.0.1", "localhost", "192.168.1.2"]

# Aplikasi bawaan Django, REST Framework, dan fitur berita.
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "news",
]

# Middleware memproses setiap request/response, misalnya session dan keamanan.
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

# Titik masuk pemetaan URL dan template server.
ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

# WSGI_APPLICATION menghubungkan Django ke server WSGI saat deployment.
WSGI_APPLICATION = "config.wsgi.application"
# SQLite menyimpan data aplikasi ke satu file lokal di folder server.
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

# Bahasa dan zona waktu yang dipakai tanggal berita.
AUTH_PASSWORD_VALIDATORS = []
LANGUAGE_CODE = "id-id"
TIME_ZONE = "Asia/Jakarta"
USE_I18N = True
USE_TZ = True
# STATIC untuk aset aplikasi web; MEDIA untuk file yang diunggah pengguna.
STATIC_URL = "static/"
# File unggahan disimpan di disk server, terpisah dari file database.
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# API hanya mengirim JSON, format yang dibaca aplikasi Android.
REST_FRAMEWORK = {
    "DEFAULT_RENDERER_CLASSES": ["rest_framework.renderers.JSONRenderer"],
}