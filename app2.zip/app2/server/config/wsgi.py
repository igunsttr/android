import os

from django.core.wsgi import get_wsgi_application

# WSGI mencari pengaturan yang sama dengan perintah manage.py.
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

# Objek ini dipanggil server WSGI untuk menangani request web.
application = get_wsgi_application()