from django.apps import AppConfig


class NewsConfig(AppConfig):
    """Metadata aplikasi berita yang didaftarkan pada konfigurasi Django."""
    default_auto_field = "django.db.models.BigAutoField"
    name = "news"