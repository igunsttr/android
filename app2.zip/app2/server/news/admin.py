from django.contrib import admin

from .models import Article, Category


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    """Mengatur kolom dan pengisian slug otomatis pada halaman admin kategori."""
    list_display = ["name", "slug"]
    prepopulated_fields = {"slug": ("name",)}


@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    """Menyediakan pencarian, filter, dan formulir tulis/unggah berita."""
    list_display = ["title", "category", "author", "is_featured", "created_at"]
    fields = ["category", "title", "slug", "summary", "body", "author", "image", "image_url", "is_featured"]
    list_filter = ["category", "is_featured", "created_at"]
    search_fields = ["title", "summary", "body"]
    prepopulated_fields = {"slug": ("title",)}