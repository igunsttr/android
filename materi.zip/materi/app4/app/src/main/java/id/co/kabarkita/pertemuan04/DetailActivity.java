package id.co.kabarkita.pertemuan04;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DetailActivity extends Activity {
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        int padding = Math.round(24 * getResources().getDisplayMetrics().density);
        page.setPadding(padding, padding, padding, padding);

        TextView title = new TextView(this);
        title.setText("Detail berita");
        title.setTextSize(26);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        page.addView(title);

        TextView body = new TextView(this);
        body.setText("Activity detail menerima navigasi dari MainActivity melalui Intent. Gunakan Intent extra untuk mengirim ID atau slug berita yang dipilih.");
        body.setTextSize(17);
        body.setPadding(0, padding, 0, 0);
        page.addView(body);
        setContentView(page);
    }
}
