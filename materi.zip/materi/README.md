# Materi Pemrograman Android dan Django ? 14 Pertemuan

Paket praktikum berisi 14 dokumen Microsoft Word dan 14 proyek Android Studio mandiri. Kurikulum bergerak dari aplikasi native Java dan API Django menuju WebView/hybrid, lalu integrasi proyek akhir.

## Daftar materi

1. [Pertemuan 01: Android native dan server Django: aplikasi berita pertama](docs/pertemuan-01.docx) ? folder praktik: `app1/`.
2. [Pertemuan 02: REST API berita, kategori, pencarian, dan gambar](docs/pertemuan-02.docx) ? folder praktik: `app2/`.
3. [Pertemuan 03: Komponen dan layout native Android](docs/pertemuan-03.docx) ? folder praktik: `app3/`.
4. [Pertemuan 04: Navigasi antarhalaman menggunakan Intent](docs/pertemuan-04.docx) ? folder praktik: `app4/`.
5. [Pertemuan 05: Form input dan validasi data](docs/pertemuan-05.docx) ? folder praktik: `app5/`.
6. [Pertemuan 06: Daftar data dan adapter Android](docs/pertemuan-06.docx) ? folder praktik: `app6/`.
7. [Pertemuan 07: Penyimpanan lokal dengan SharedPreferences](docs/pertemuan-07.docx) ? folder praktik: `app7/`.
8. [Pertemuan 08: Model Django dan migrasi database](docs/pertemuan-08.docx) ? folder praktik: `app8/`.
9. [Pertemuan 09: REST API dan JSON dengan Django REST Framework](docs/pertemuan-09.docx) ? folder praktik: `app9/`.
10. [Pertemuan 10: Jaringan asinkron dan penanganan error](docs/pertemuan-10.docx) ? folder praktik: `app10/`.
11. [Pertemuan 11: Hybrid lokal: HTML, CSS, JavaScript, dan Android](docs/pertemuan-11.docx) ? folder praktik: `app11/`.
12. [Pertemuan 12: WebView untuk halaman Django](docs/pertemuan-12.docx) ? folder praktik: `app12/`.
13. [Pertemuan 13: Hybrid: mengirim formulir ke REST API Django](docs/pertemuan-13.docx) ? folder praktik: `app13/`.
14. [Pertemuan 14: Proyek akhir: KabarKita native, hybrid, dan Django](docs/pertemuan-14.docx) ? folder praktik: `app14/`.

## Menjalankan praktik

Setiap folder `appN` memiliki README dan proyek Android/Django mandiri. Buka folder yang sesuai di Android Studio. Jalankan server dengan petunjuk README di folder proyek; gunakan emulator Android dan `10.0.2.2:8000`. Pertemuan 1?2 menggunakan contoh yang sudah tersedia di `app1` dan `app2`; pertemuan 3?14 merupakan proyek praktik terpisah.

## Prasyarat

- Android Studio, Android SDK Platform 35, dan JDK 17.
- Python dengan Django 5.2, Django REST Framework, dan Pillow sesuai `requirements.txt` masing-masing proyek.
- Emulator Android; untuk perangkat fisik, atur alamat API dan `ALLOWED_HOSTS` ke IP LAN komputer.
- Server `runserver` dan HTTP cleartext dipakai untuk latihan lokal. Jangan gunakan `DEBUG=True` atau konfigurasi contoh sebagai deployment publik.
