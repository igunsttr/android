package id.co.kabarkita.pertemuan14;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final String API = "http://10.0.2.2:8000/api/";
    private final ArrayList<JSONObject> articles = new ArrayList<>();
    private final ArrayList<String> titles = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private TextView status;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        int padding = Math.round(18 * getResources().getDisplayMetrics().density);
        page.setPadding(padding, padding, padding, padding);

        TextView heading = new TextView(this);
        heading.setText("KabarKita — Proyek Akhir");
        heading.setTextSize(24);
        heading.setTypeface(null, android.graphics.Typeface.BOLD);
        page.addView(heading);

        status = new TextView(this);
        status.setText("Hubungkan aplikasi ke server Django.");
        page.addView(status);

        Button refresh = new Button(this);
        refresh.setText("Muat ulang berita");
        page.addView(refresh);

        ListView list = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, titles);
        list.setAdapter(adapter);
        page.addView(list, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(page);

        refresh.setOnClickListener(view -> loadArticles());
        list.setOnItemClickListener((parent, row, position, id) -> showArticle(position));
        loadArticles();
    }

    private void loadArticles() {
        status.setText("Memuat artikel...");
        request("articles/", response -> {
            try {
                JSONArray result = new JSONArray(response);
                articles.clear();
                titles.clear();
                for (int i = 0; i < result.length(); i++) {
                    JSONObject article = result.getJSONObject(i);
                    articles.add(article);
                    titles.add(article.optString("title", "Tanpa judul")
                            + "\n" + article.optString("summary", ""));
                }
                adapter.notifyDataSetChanged();
                status.setText("Artikel tersedia: " + articles.size()
                        + ". Ketuk judul untuk membuka detail.");
            } catch (Exception e) {
                status.setText("JSON artikel tidak dapat dibaca: " + e.getMessage());
            }
        });
    }

    private void showArticle(int position) {
        JSONObject article = articles.get(position);
        new AlertDialog.Builder(this)
                .setTitle(article.optString("title", "Detail artikel"))
                .setMessage(article.optString("body", article.optString("summary", "")))
                .setPositiveButton("Tutup", null)
                .show();
    }

    private interface ResponseHandler {
        void onSuccess(String body);
    }

    private void request(String path, ResponseHandler handler) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(API + path).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setRequestMethod("GET");
                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 300
                        ? connection.getInputStream() : connection.getErrorStream();
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        body.append(line);
                    }
                }
                String response = body.toString();
                if (code < 200 || code >= 300) {
                    throw new IllegalStateException("HTTP " + code + ": " + response);
                }
                runOnUiThread(() -> handler.onSuccess(response));
            } catch (Exception e) {
                String message = e.getMessage() == null ? "Permintaan gagal" : e.getMessage();
                runOnUiThread(() -> status.setText("Gagal memuat artikel: " + message));
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }
}
