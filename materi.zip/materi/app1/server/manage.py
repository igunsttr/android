#!/usr/bin/env python
# os mengatur variabel konfigurasi untuk proses Python.
import os
# sys meneruskan argumen perintah terminal kepada Django.
import sys


def main():
    # Memilih modul pengaturan Django yang dipakai server.
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
    # Mengimpor pemanggil perintah setelah konfigurasi tersedia.
    from django.core.management import execute_from_command_line

    # Menjalankan perintah yang diketik, seperti migrate atau runserver.
    execute_from_command_line(sys.argv)


# Menjalankan main hanya jika file ini dipanggil langsung dari terminal.
if __name__ == "__main__":
    main()