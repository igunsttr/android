"""Pengaturan utama Django untuk server berita pembelajaran."""

# Path membantu menyusun lokasi folder proyek dengan aman di berbagai OS.
from pathlib import Path


# Menghitung folder server sebagai dasar lokasi database dan file proyek.
BASE_DIR = Path(__file__).resolve().parent.parent
# Kunci lokal untuk fitur keamanan Django; ganti sebelum deployment.
SECRET_KEY = "development-only-change-me"
# Mode debug memudahkan belajar, tetapi tidak boleh aktif di server publik.
DEBUG = True
# Mengizinkan browser laptop dan HP mengakses server pada jaringan lokal.
ALLOWED_HOSTS = ["localhost", "127.0.0.1", "10.0.2.2", "192.168.1.8"]

# Mendaftarkan fitur bawaan Django dan aplikasi berita buatan kita.
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "news",
]

# Middleware memproses request/response untuk keamanan dan fitur web Django.
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

# Menunjuk modul yang memetakan alamat URL ke fungsi penangan request.
ROOT_URLCONF = "config.urls"
# Menyiapkan mesin template yang digunakan halaman Admin Django.
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]
# Menentukan aplikasi WSGI jika server dijalankan oleh server web.
WSGI_APPLICATION = "config.wsgi.application"

# Menggunakan SQLite agar mahasiswa tidak perlu memasang database terpisah.
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

# Menonaktifkan validasi password tambahan untuk setup lokal sederhana.
AUTH_PASSWORD_VALIDATORS = []
# Menampilkan tanggal dan teks dengan pengaturan bahasa Indonesia.
LANGUAGE_CODE = "id"
# Menyetel zona waktu ke WIB.
TIME_ZONE = "Asia/Jakarta"
# Mengaktifkan fitur terjemahan Django.
USE_I18N = True
# Menyimpan waktu database secara sadar zona waktu.
USE_TZ = True
# Menetapkan URL dasar untuk file statis Django.
STATIC_URL = "static/"
# URL lokal yang dipakai browser dan client untuk meminta file unggahan.
MEDIA_URL = "/media/"
# Folder server/media menjadi lokasi penyimpanan gambar yang diunggah.
MEDIA_ROOT = BASE_DIR / "media"
# Memakai primary key BigAutoField secara default pada model baru.
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"