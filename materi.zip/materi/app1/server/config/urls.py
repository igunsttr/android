# settings menyediakan lokasi file media dan status debug proyek.
from django.conf import settings
# static menyiapkan penyajian file media saat pengembangan lokal.
from django.conf.urls.static import static
# admin menyediakan antarmuka pengelolaan data Django.
from django.contrib import admin
# path membuat rute URL dan include menghubungkan rute aplikasi lain.
from django.urls import include, path


# Mengarahkan alamat admin dan API ke modul pemiliknya.
urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include("news.urls")),
]

# Melayani gambar unggahan hanya saat server berjalan dalam mode debug.
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)