# os mengatur variabel konfigurasi proses Python.
import os

# Mengimpor factory aplikasi WSGI dari Django.
from django.core.wsgi import get_wsgi_application

# Memilih file pengaturan proyek Django.
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
# Membuat objek aplikasi yang dipanggil server WSGI.
application = get_wsgi_application()