"""View yang mengubah data berita menjadi respons JSON."""

# JsonResponse mengirim data Python dalam format JSON ke client.
from django.http import JsonResponse
# Helper ini mencari data atau otomatis mengembalikan HTTP 404.
from django.shortcuts import get_object_or_404

# Mengimpor tabel berita yang akan dibaca dari database.
from .models import Article


# Menyusun satu model berita menjadi struktur data sederhana.
def article_data(article, request):
    return {
        # ID dipakai client untuk mengenali berita.
        "id": article.id,
        # Field teks berikut dikirim agar aplikasi dapat menampilkan berita.
        "title": article.title,
        "summary": article.summary,
        "content": article.content,
        "author": article.author,
        "category": article.category,
        # URL file lokal dipakai jika ada; URL eksternal menjadi pilihan cadangan.
        "image_url": (
            request.build_absolute_uri(article.image.url)
            if article.image
            else article.image_url
        ),
        # Waktu diubah menjadi teks ISO agar mudah dibaca oleh client.
        "published_at": article.published_at.isoformat(),
    }


def article_list(request):
    # Draf tetap tersimpan di database tetapi tidak dikirim ke aplikasi.
    articles = Article.objects.filter(is_published=True)
    # Mengirim daftar berita di dalam objek dengan properti articles.
    return JsonResponse({
        "articles": [article_data(article, request) for article in articles]
    })


def article_detail(request, article_id):
    # Berita draf dianggap tidak ditemukan oleh client.
    article = get_object_or_404(Article, id=article_id, is_published=True)
    # Mengirim detail satu artikel sebagai JSON.
    return JsonResponse(article_data(article, request))