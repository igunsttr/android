"""Pengaturan tampilan data berita pada Django Admin."""

# Mengimpor fitur Admin bawaan Django.
from django.contrib import admin

# Mengimpor model berita yang akan dikelola administrator.
from .models import Article


# Menghubungkan pengaturan di bawah dengan model Article.
@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    # Memilih kolom yang tampak pada tabel daftar berita.
    list_display = ("title", "image", "category", "author", "published_at", "is_published")
    # Menambahkan filter agar berita mudah dikelompokkan di Admin.
    list_filter = ("category", "is_published", "published_at")
    # Mengaktifkan pencarian berdasarkan judul, ringkasan, dan isi.
    search_fields = ("title", "summary", "content")
    # Mengizinkan status terbit diubah langsung dari tabel daftar.
    list_editable = ("is_published",)
    # Menempatkan berita terbaru pada bagian paling atas.
    ordering = ("-published_at",)