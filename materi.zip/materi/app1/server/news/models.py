"""Model data berita yang disimpan dalam database."""

# Mengimpor tipe field dan model dasar dari Django.
from django.db import models


# Article mewakili satu berita pada tabel database.
class Article(models.Model):
    # Judul berita dibatasi maksimal 200 karakter.
    title = models.CharField(max_length=200)
    # Ringkasan singkat ditampilkan pada daftar berita di aplikasi.
    summary = models.CharField(max_length=300)
    # Isi lengkap berita dapat memiliki panjang teks bebas.
    content = models.TextField()
    # Nama penulis memakai nilai Redaksi jika tidak diisi.
    author = models.CharField(max_length=100, default="Redaksi")
    # Kategori berita memakai kategori Umum sebagai nilai awal.
    category = models.CharField(max_length=60, default="Umum")
    # URL gambar eksternal tetap tersedia untuk artikel lama.
    image_url = models.URLField(blank=True)
    # File gambar yang diunggah dari Admin disimpan di MEDIA_ROOT/news/.
    image = models.ImageField(upload_to="news/", blank=True)
    # Django mengisi waktu ini saat berita pertama kali dibuat.
    published_at = models.DateTimeField(auto_now_add=True)
    # Berita draf tidak ditampilkan oleh API untuk client.
    is_published = models.BooleanField(default=True)

    # Mengatur urutan dan nama model pada halaman Admin.
    class Meta:
        # Berita terbaru muncul lebih dahulu.
        ordering = ["-published_at"]
        # Nama yang ditampilkan pada halaman Admin.
        verbose_name = "Berita"
        verbose_name_plural = "Berita"

    # Menampilkan judul ketika objek terlihat di Admin atau log.
    def __str__(self):
        return self.title