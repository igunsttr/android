"""Pemetaan alamat API berita ke fungsi view."""

# path membuat satu rute URL untuk dipanggil client.
from django.urls import path

# views berisi fungsi yang menangani request API.
from . import views


# Mendaftarkan endpoint daftar berita dan endpoint detail berdasarkan ID.
urlpatterns = [
    # Endpoint ini mengirim seluruh berita yang sudah diterbitkan.
    path("news/", views.article_list, name="article-list"),
    # <int:article_id> mengambil ID angka dari bagian URL.
    path("news/<int:article_id>/", views.article_detail, name="article-detail"),
]