# tempfile menyediakan folder media sementara selama tes berjalan.
import tempfile

# SimpleUploadedFile meniru file yang dikirim melalui form upload.
from django.core.files.uploadedfile import SimpleUploadedFile
# TestCase menyediakan database sementara untuk setiap tes Django.
from django.test import TestCase
from django.urls import reverse

from .models import Article


class ArticleApiTests(TestCase):
    def setUp(self):
        self.published = Article.objects.create(
            title="Berita tampil",
            summary="Ringkasan berita",
            content="Isi berita",
        )
        # Berita ini tidak boleh dikirim karena statusnya draf.
        Article.objects.create(
            title="Berita draf",
            summary="Belum diterbitkan",
            content="Isi draf",
            is_published=False,
        )

    # Menyiapkan satu berita terbit dan satu berita draf sebelum setiap tes.
    def test_list_returns_only_published_articles(self):
        # Memanggil endpoint daftar menggunakan Django test client.
        response = self.client.get(reverse("article-list"))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json()["articles"]), 1)
        self.assertEqual(response.json()["articles"][0]["id"], self.published.id)

    # Memastikan endpoint detail mengirim judul berita yang diminta.
    def test_detail_returns_published_article(self):
        response = self.client.get(reverse("article-detail", args=[self.published.id]))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["title"], "Berita tampil")

    # Memastikan berita draf tidak bisa dibaca lewat endpoint detail.
    def test_detail_hides_unpublished_article(self):
        draft = Article.objects.get(is_published=False)

        # Meminta berita draf untuk memeriksa bahwa API membalas 404.
        response = self.client.get(reverse("article-detail", args=[draft.id]))

        self.assertEqual(response.status_code, 404)

    # Memastikan API mengirim URL yang dapat dipakai untuk membuka gambar lokal.
    def test_list_returns_local_image_url(self):
        with tempfile.TemporaryDirectory() as media_directory:
            with self.settings(MEDIA_ROOT=media_directory):
                article = Article.objects.create(
                    title="Berita bergambar",
                    summary="Ringkasan berita",
                    content="Isi berita",
                    image=SimpleUploadedFile(
                        "sampul.jpg",
                        b"data gambar contoh",
                        content_type="image/jpeg",
                    ),
                )
                response = self.client.get(reverse("article-list"))

        article_data = next(
            item for item in response.json()["articles"] if item["id"] == article.id
        )
        self.assertEqual(
            article_data["image_url"],
            "http://testserver/media/news/sampul.jpg",
        )