"""Migration awal untuk membuat tabel berita."""

# migrations menjalankan perubahan database; models mendefinisikan kolom.
from django.db import migrations, models


# Migration ini membuat tabel Article saat perintah migrate dijalankan.
class Migration(migrations.Migration):
    # Menandai file ini sebagai migration pertama aplikasi berita.
    initial = True

    # Tidak ada migration aplikasi berita sebelumnya yang perlu dijalankan.
    dependencies = []

    # Daftar perubahan database yang dikerjakan migration ini.
    operations = [
        # Membuat tabel database dengan field yang sama seperti model Article.
        migrations.CreateModel(
            name="Article",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=200)),
                ("summary", models.CharField(max_length=300)),
                ("content", models.TextField()),
                ("author", models.CharField(default="Redaksi", max_length=100)),
                ("category", models.CharField(default="Umum", max_length=60)),
                ("image_url", models.URLField(blank=True)),
                ("published_at", models.DateTimeField(auto_now_add=True)),
                ("is_published", models.BooleanField(default=True)),
            ],
            # Urutan bawaan tabel mengikuti berita yang paling baru.
            options={
                "verbose_name": "Berita",
                "verbose_name_plural": "Berita",
                "ordering": ["-published_at"],
            },
        ),
    ]