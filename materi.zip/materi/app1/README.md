# Portal Berita Android

Contoh aplikasi portal berita native Android dengan client Java dan server Django. Artikel dikelola melalui Django Admin, lalu dibaca oleh aplikasi Android lewat API JSON.

## Menjalankan server

Pastikan Python 3.10 atau lebih baru tersedia. Jalankan perintah berikut dari folder utama proyek di PowerShell:

```powershell
python -m venv .venv  # Membuat lingkungan Python terpisah untuk dependensi proyek.
.\.venv\Scripts\Activate.ps1  # Mengaktifkan lingkungan Python pada sesi PowerShell ini.
python -m pip install -r server/requirements.txt  # Memasang Django dari daftar dependensi proyek.
python server/manage.py migrate  # Membuat tabel database berdasarkan model dan migration.
python server/manage.py createsuperuser  # Membuat akun administrator untuk masuk ke Django Admin.
python server/manage.py runserver 0.0.0.0:8000  # Menjalankan API pada port 8000 dan menerima koneksi jaringan lokal.
```

Buka `http://127.0.0.1:8000/admin/`, masuk menggunakan akun superuser, lalu tambahkan berita. Pastikan **is published** aktif agar berita dikirim ke client.

Pada formulir berita, pilih file di kolom **image** untuk mengunggah gambar. Django menyimpan file secara lokal di `server/media/news/`, sedangkan nama/path file disimpan pada kolom database. API mengirim URL file tersebut melalui `image_url`; jika tidak ada file lokal, API menggunakan nilai dari kolom `image_url` lama. Dependensi Pillow untuk validasi gambar dipasang bersama Django dari `server/requirements.txt`.

API yang tersedia:

- `GET /api/news/` mengirim daftar berita terbit dalam properti `articles`.
- `GET /api/news/<id>/` mengirim satu berita terbit.

Jalankan tes backend dengan perintah ini dari folder utama proyek:

```powershell
python server/manage.py test news  # Menjalankan tes endpoint berita dan penyaringan draf.
```

## Menjalankan aplikasi Android

1. Buka folder utama proyek ini di Android Studio.
2. Gunakan JDK 17 dan pasang Android SDK Platform 35 ketika diminta, lalu tunggu Gradle Sync selesai.
3. Jalankan konfigurasi `app` pada emulator Android.

Client memakai `http://10.0.2.2:8000/api/news/`. Alamat tersebut meneruskan koneksi dari emulator ke komputer host. Jalankan server lebih dulu sebelum membuka aplikasi.

Untuk perangkat Android fisik, ubah konstanta `API_URL` di `app/src/main/java/com/example/portalberita/MainActivity.java` menjadi alamat IP lokal komputer, misalnya `http://192.168.1.10:8000/api/news/`. Pastikan komputer dan perangkat memakai jaringan Wi-Fi yang sama dan firewall mengizinkan port 8000.

## Bahan pertemuan pertama

- `Article` di `server/news/models.py` mendefinisikan struktur data berita.
- `server/news/admin.py` mendaftarkan model agar dapat dikelola melalui Django Admin.
- `server/news/views.py` mengubah data model menjadi JSON untuk client.
- Unggahan gambar dikelola oleh `ImageField` dan disimpan di folder media lokal saat development.
- `MainActivity.java` mengambil JSON di thread latar belakang, menguraikannya, dan menampilkan daftar native Android. Ketuk berita untuk membaca isi lengkap.
- `NewsAdapter` menghubungkan data berita dengan baris pada `ListView`.
- Komentar bahasa Indonesia di file kode menjelaskan fungsi perintah dan bagian utama program.

Latihan lanjutan: tambahkan kategori sebagai filter, tampilkan gambar berita, atau buat layar detail terpisah. HTTP tanpa enkripsi dan `DEBUG=True` hanya untuk pembelajaran lokal; gunakan HTTPS dan konfigurasi deployment yang aman sebelum aplikasi dipublikasikan.

Bahan ajar: [Materi Pertemuan 1](../docs/pertemuan-01.docx). Indeks seluruh rangkaian tersedia di [README utama](../README.md).