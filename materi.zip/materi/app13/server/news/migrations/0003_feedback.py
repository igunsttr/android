from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("news", "0002_article_image")]
    operations = [migrations.CreateModel(name="Feedback", fields=[
        ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
        ("name", models.CharField(max_length=80)),
        ("message", models.CharField(max_length=500)),
        ("created_at", models.DateTimeField(auto_now_add=True)),
    ], options={"ordering": ["-created_at"]})]
