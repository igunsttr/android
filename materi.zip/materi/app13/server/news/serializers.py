from rest_framework import serializers

from .models import Article, Category, Feedback


class CategorySerializer(serializers.ModelSerializer):
    """Memilih field kategori yang boleh dikirim sebagai JSON ke klien."""
    article_count = serializers.IntegerField(source="articles.count", read_only=True)

    class Meta:
        model = Category
        fields = ["id", "name", "slug", "article_count"]


class ArticleSerializer(serializers.ModelSerializer):
    """Mengubah model berita ke JSON, termasuk nama kategori dan URL gambar."""
    category = serializers.CharField(source="category.name", read_only=True)
    category_slug = serializers.CharField(source="category.slug", read_only=True)
    image_url = serializers.SerializerMethodField()

    def get_image_url(self, article):
        """Kirim URL absolut untuk gambar lokal atau pertahankan URL eksternal."""
        # URL penuh membuat lokasi media bisa diakses dari perangkat Android.
        if article.image:
            request = self.context.get("request")
            image_url = article.image.url
            return request.build_absolute_uri(image_url) if request else image_url
        return article.image_url

    class Meta:
        model = Article
        fields = [
            "id",
            "title",
            "slug",
            "summary",
            "body",
            "author",
            "image_url",
            "is_featured",
            "created_at",
            "category",
            "category_slug",
        ]

class FeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = Feedback
        fields = ["id", "name", "message", "created_at"]
        read_only_fields = ["id", "created_at"]
