from rest_framework.test import APITestCase
from .models import Feedback


class FeedbackApiTests(APITestCase):
    def test_post_creates_feedback(self):
        response = self.client.post("/api/feedback/", {"name": "Ayu", "message": "Materi jelas"}, format="json")
        self.assertEqual(response.status_code, 201)
        self.assertEqual(Feedback.objects.count(), 1)
        self.assertEqual(response.data["name"], "Ayu")

    def test_post_requires_name_and_message(self):
        response = self.client.post("/api/feedback/", {"name": ""}, format="json")
        self.assertEqual(response.status_code, 400)
        self.assertEqual(Feedback.objects.count(), 0)
