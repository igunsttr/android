from django.db.models import Q
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import Article, Category, Feedback
from .serializers import ArticleSerializer, CategorySerializer, FeedbackSerializer


@api_view(["GET"])
def categories(request):
    """Kirim semua kategori beserta jumlah berita di setiap kategori."""
    items = Category.objects.all().prefetch_related("articles")
    return Response(CategorySerializer(items, many=True).data)


@api_view(["GET"])
def articles(request):
    """Kirim daftar berita; query parameter dapat membatasi kategori atau kata."""
    items = Article.objects.select_related("category")
    category_slug = request.query_params.get("category")
    search = request.query_params.get("search", "").strip()

    # Filter diterapkan ke queryset sebelum objek dikonversi menjadi JSON.
    if category_slug:
        items = items.filter(category__slug=category_slug)
    if search:
        items = items.filter(
            Q(title__icontains=search)
            | Q(summary__icontains=search)
            | Q(body__icontains=search)
            | Q(category__name__icontains=search)
        )
    return Response(
        ArticleSerializer(items[:100], many=True, context={"request": request}).data
    )


@api_view(["GET"])
def article_detail(request, slug):
    """Cari berita berdasarkan slug, lalu kirim 404 jika berita tidak ada."""
    item = get_object_or_404(Article.objects.select_related("category"), slug=slug)
    return Response(ArticleSerializer(item, context={"request": request}).data)

@api_view(["GET", "POST"])
def feedback(request):
    """Baca daftar umpan balik atau simpan satu pesan tervalidasi."""
    if request.method == "POST":
        serializer = FeedbackSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    items = Feedback.objects.all()[:50]
    return Response(FeedbackSerializer(items, many=True).data)
