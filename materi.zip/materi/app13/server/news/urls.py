from django.urls import path

from . import views


# Setiap pola menghubungkan path API dengan fungsi view yang melayani request.
urlpatterns = [
    path("feedback/", views.feedback, name="feedback-list"),
    path("categories/", views.categories, name="category-list"),
    path("articles/", views.articles, name="article-list"),
    path("articles/<slug:slug>/", views.article_detail, name="article-detail"),
]