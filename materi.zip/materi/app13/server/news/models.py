from django.db import models
from django.utils.text import slugify


class Category(models.Model):
    """Kategori untuk mengelompokkan artikel dan menavigasi topik di Android."""
    name = models.CharField(max_length=60, unique=True)
    slug = models.SlugField(max_length=70, unique=True, blank=True)

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "categories"

    def save(self, *args, **kwargs):
        """Buat slug URL dari nama jika slug belum diberikan admin."""
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        """Tampilkan nama kategori pada admin dan shell Django."""
        return self.name


class Article(models.Model):
    """Satu berita beserta teks, kategori, gambar, dan waktu publikasinya."""
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="articles")
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    summary = models.CharField(max_length=300)
    body = models.TextField()
    author = models.CharField(max_length=100, default="Redaksi KabarKita")
    # Database menyimpan path relatif; file fisiknya berada di MEDIA_ROOT/articles/.
    image = models.ImageField(upload_to="articles/", blank=True)
    image_url = models.URLField(blank=True)
    is_featured = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-is_featured", "-created_at"]

    def save(self, *args, **kwargs):
        """Buat slug unik dari judul sebelum record disimpan ke database."""
        if not self.slug:
            base_slug = slugify(self.title)
            self.slug = base_slug
            suffix = 2
            while Article.objects.filter(slug=self.slug).exclude(pk=self.pk).exists():
                self.slug = f"{base_slug}-{suffix}"
                suffix += 1
        super().save(*args, **kwargs)

    def __str__(self):
        """Gunakan judul sebagai nama berita yang mudah dikenali."""
        return self.title

class Feedback(models.Model):
    """Pesan singkat yang dikirim dari formulir hybrid Android."""
    name = models.CharField(max_length=80)
    message = models.CharField(max_length=500)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name}: {self.message[:40]}"
