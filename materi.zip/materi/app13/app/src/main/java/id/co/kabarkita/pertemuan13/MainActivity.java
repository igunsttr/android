package id.co.kabarkita.pertemuan13;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String API = "http://10.0.2.2:8000/api/";
    private WebView webView;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); webView = new WebView(this); setContentView(webView);
        WebSettings settings = webView.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }
    private class AndroidBridge {
        @JavascriptInterface public void loadArticles() {
            send("GET", "articles/", null, body -> webView.evaluateJavascript("showArticles(" + JSONObject.quote(body) + ")", null));
        }
        @JavascriptInterface public void submitFeedback(String name, String message) {
            try { JSONObject payload = new JSONObject(); payload.put("name", name); payload.put("message", message);
                send("POST", "feedback/", payload.toString(), body -> webView.evaluateJavascript("showResult(" + JSONObject.quote("Umpan balik tersimpan: " + body) + ")", null));
            } catch (Exception e) { report(e.getMessage()); }
        }
    }
    private interface Success { void accept(String body); }
    private void send(String method, String path, String payload, Success success) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try { connection = (HttpURLConnection) new URL(API + path).openConnection(); connection.setConnectTimeout(5000); connection.setReadTimeout(5000); connection.setRequestMethod(method);
                if (payload != null) { connection.setDoOutput(true); connection.setRequestProperty("Content-Type", "application/json; charset=utf-8"); try (OutputStream out = connection.getOutputStream()) { out.write(payload.getBytes(StandardCharsets.UTF_8)); } }
                int code = connection.getResponseCode(); InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream(); StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) { String line; while ((line = reader.readLine()) != null) body.append(line); }
                String response = body.toString(); if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + response);
                runOnUiThread(() -> success.accept(response));
            } catch (Exception e) { report(e.getMessage() == null ? "Permintaan gagal" : e.getMessage()); } finally { if (connection != null) connection.disconnect(); }
        }).start();
    }
    private void report(String message) { runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show()); }
}
