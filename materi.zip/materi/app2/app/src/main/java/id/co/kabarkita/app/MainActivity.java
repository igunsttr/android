package id.co.kabarkita.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Activity utama yang mengatur layar, navigasi, komunikasi API, dan gambar berita.
public class MainActivity extends Activity {
    private static final String API_BASE = "http://192.168.1.8:8000/api/news";
    private static final int INK = Color.rgb(35, 39, 37);
    private static final int MUTED = Color.rgb(112, 119, 112);
    private static final int PAPER = Color.rgb(244, 242, 235);
    private static final int WHITE = Color.WHITE;
    private static final int ACCENT = Color.rgb(216, 85, 63);
    private static final int LINE = Color.rgb(222, 220, 211);

    // Executor mengerjakan operasi jaringan di luar main thread agar UI tidak macet.
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    // Handler mengirim hasil pekerjaan latar kembali ke thread yang boleh mengubah UI.
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    // Cache sederhana untuk konten yang sudah diterima selama Activity hidup.
    private final List<Article> articles = new ArrayList<>();
    private final List<Category> categories = new ArrayList<>();
    private LinearLayout pageContent;
    private EditText searchInput;
    private String currentScreen = "home";
    private String activeCategory = "";
    private String currentQuery = "";
    private Article selectedArticle;
    private boolean loading;
    private String loadError = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Lifecycle Android: siapkan warna system bar, gambar kerangka layar, lalu ambil data.
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(PAPER);
        getWindow().setNavigationBarColor(PAPER);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        renderShell();
        loadCategories();
        loadArticles();
    }

    @Override
    protected void onDestroy() {
        // Hentikan pekerjaan latar agar tidak berjalan setelah Activity ditutup.
        executor.shutdownNow();
        super.onDestroy();
    }

    private void renderShell() {
        // Susun kerangka tetap aplikasi: header pencarian, area yang bergulir, dan menu bawah.
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(PAPER);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(22), dp(18), dp(22), dp(12));
        TextView brand = text("KABARKITA", 13, ACCENT, true);
        brand.setLetterSpacing(0.12f);
        header.addView(brand);
        TextView tagline = text("Berita yang dekat dengan kita.", 22, INK, true);
        LinearLayout.LayoutParams taglineParams = new LinearLayout.LayoutParams(-1, -2);
        taglineParams.topMargin = dp(4);
        header.addView(tagline, taglineParams);

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        searchRow.setPadding(dp(12), 0, dp(8), 0);
        searchRow.setBackground(background(WHITE, LINE, 1, 12));
        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextSize(15);
        searchInput.setTextColor(INK);
        searchInput.setHintTextColor(MUTED);
        searchInput.setHint("Cari berita atau topik");
        searchInput.setBackgroundColor(Color.TRANSPARENT);
        searchInput.setInputType(InputType.TYPE_CLASS_TEXT);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchRow.addView(searchInput, new LinearLayout.LayoutParams(0, dp(46), 1));
        Button searchButton = smallButton("Cari", ACCENT, WHITE);
        searchButton.setOnClickListener(view -> submitSearch());
        searchRow.addView(searchButton);
        searchInput.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                submitSearch();
                return true;
            }
            return false;
        });
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, -2);
        searchParams.topMargin = dp(14);
        header.addView(searchRow, searchParams);
        root.addView(header);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        pageContent = new LinearLayout(this);
        pageContent.setOrientation(LinearLayout.VERTICAL);
        pageContent.setPadding(dp(22), dp(8), dp(22), dp(24));
        scrollView.addView(pageContent);
        root.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(dp(10), dp(8), dp(10), dp(8));
        nav.setBackgroundColor(WHITE);
        nav.setElevation(dp(8));
        nav.addView(navButton("Beranda", "home"), new LinearLayout.LayoutParams(0, dp(48), 1));
        nav.addView(navButton("Topik", "topics"), new LinearLayout.LayoutParams(0, dp(48), 1));
        nav.addView(navButton("Tersimpan", "saved"), new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(nav);

        setContentView(root);
        renderPage();
    }

    private Button navButton(String label, String screen) {
        // Tombol menu mengubah state halaman, lalu meminta data bila layar memerlukannya.
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(12);
        button.setAllCaps(false);
        button.setTextColor(currentScreen.equals(screen) ? ACCENT : MUTED);
        button.setBackgroundColor(Color.TRANSPARENT);
        button.setOnClickListener(view -> {
            currentScreen = screen;
            activeCategory = "";
            currentQuery = "";
            renderShell();
            if (screen.equals("home") || screen.equals("saved")) {
                loadArticles();
            }
        });
        return button;
    }

    private void renderPage() {
        // Pilih isi area utama berdasarkan state; detail/topik/tersimpan punya renderer sendiri.
        if (pageContent == null) return;
        pageContent.removeAllViews();
        if (selectedArticle != null && currentScreen.equals("detail")) {
            renderDetail(selectedArticle);
            return;
        }
        if (currentScreen.equals("topics")) {
            renderTopics();
            return;
        }
        if (currentScreen.equals("saved")) {
            renderSaved();
            return;
        }

        String heading = currentScreen.equals("category") ? activeCategory
                : currentScreen.equals("search") ? "Hasil pencarian" : "Pilihan redaksi";
        addSectionTitle(heading, currentScreen.equals("home") ? "CERITA HARI INI" : "JELAJAHI BERITA");
        if (currentScreen.equals("home") && !categories.isEmpty()) renderCategoryStrip();
        if (!currentQuery.isEmpty()) {
            TextView query = text("Untuk: “" + currentQuery + "”", 14, MUTED, false);
            pageContent.addView(query, bottomSpace(dp(12)));
        }
        if (loading && articles.isEmpty()) {
            addMessage("Sedang memuat berita…");
        } else if (!loadError.isEmpty() && articles.isEmpty()) {
            addMessage(loadError + "\nPastikan server Django berjalan, lalu buka kembali halaman.");
            Button retry = smallButton("Coba lagi", ACCENT, WHITE);
            retry.setOnClickListener(view -> loadArticles());
            pageContent.addView(retry, bottomSpace(dp(16)));
        } else {
            List<Article> visible = visibleArticles();
            if (visible.isEmpty()) addMessage("Belum ada berita untuk ditampilkan.");
            for (int index = 0; index < visible.size(); index++) {
                Article article = visible.get(index);
                pageContent.addView(articleRow(article, index == 0 && currentScreen.equals("home")));
            }
        }
    }

    private void renderCategoryStrip() {
        // Buat daftar chip kategori yang dapat digeser secara horizontal.
        HorizontalScrollView topicsScroll = new HorizontalScrollView(this);
        topicsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (Category category : categories) {
            Button button = smallButton(category.name, WHITE, INK);
            button.setBackground(background(WHITE, LINE, 1, 18));
            button.setOnClickListener(view -> openCategory(category));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(38));
            params.rightMargin = dp(8);
            row.addView(button, params);
        }
        topicsScroll.addView(row);
        pageContent.addView(topicsScroll, bottomSpace(dp(18)));
    }

    private void renderTopics() {
        // Tampilkan semua kategori sebagai pilihan untuk membuka daftar berita terkait.
        addSectionTitle("Topik", "PILIH KATEGORI");
        if (categories.isEmpty()) {
            addMessage(loading ? "Memuat topik…" : "Topik belum tersedia. Periksa koneksi server.");
            return;
        }
        for (Category category : categories) {
            LinearLayout topic = new LinearLayout(this);
            topic.setGravity(Gravity.CENTER_VERTICAL);
            topic.setPadding(dp(16), dp(14), dp(16), dp(14));
            topic.setBackground(background(WHITE, LINE, 1, 12));
            topic.setClickable(true);
            topic.setFocusable(true);
            TextView name = text(category.name, 17, INK, true);
            topic.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
            TextView count = text(category.articleCount + " berita   →", 13, MUTED, false);
            topic.addView(count);
            topic.setOnClickListener(view -> openCategory(category));
            pageContent.addView(topic, bottomSpace(dp(9)));
        }
    }

    private void renderSaved() {
        // Cocokkan slug yang tersimpan di perangkat dengan artikel yang sudah dimuat.
        addSectionTitle("Tersimpan", "KOLEKSI PRIBADI");
        Set<String> saved = savedSlugs();
        List<Article> visible = new ArrayList<>();
        for (Article article : articles) if (saved.contains(article.slug)) visible.add(article);
        if (visible.isEmpty()) {
            addMessage("Berita yang kamu simpan akan muncul di sini.");
            if (!loading && !saved.isEmpty()) {
                Button refresh = smallButton("Muat ulang", ACCENT, WHITE);
                refresh.setOnClickListener(view -> loadArticles());
                pageContent.addView(refresh);
            }
        } else {
            for (Article article : visible) pageContent.addView(articleRow(article, false));
        }
    }

    private void renderDetail(Article article) {
        // Tampilkan isi penuh artikel dan tindakan simpan untuk artikel maupun gambarnya.
        Button back = smallButton("←  Kembali ke berita", PAPER, INK);
        back.setOnClickListener(view -> {
            selectedArticle = null;
            currentScreen = "home";
            renderShell();
        });
        pageContent.addView(back, bottomSpace(dp(14)));
        TextView category = text(article.category.toUpperCase(), 12, ACCENT, true);
        category.setLetterSpacing(0.1f);
        pageContent.addView(category, bottomSpace(dp(8)));
        TextView title = text(article.title, 28, INK, true);
        pageContent.addView(title, bottomSpace(dp(12)));
        TextView byline = text(article.author + "  ·  " + article.dateLabel, 13, MUTED, false);
        pageContent.addView(byline, bottomSpace(dp(20)));
        if (!article.imageUrl.isEmpty()) {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            pageContent.addView(image, bottomSpace(dp(12), dp(220)));
            loadImage(article.imageUrl, image);
            Button saveImage = smallButton("Unduh gambar", WHITE, ACCENT);
            saveImage.setBackground(background(WHITE, LINE, 1, 12));
            saveImage.setOnClickListener(view -> saveImageLocally(article));
            pageContent.addView(saveImage, bottomSpace(dp(18)));
        }
        TextView summary = text(article.summary, 18, INK, true);
        pageContent.addView(summary, bottomSpace(dp(18)));
        View divider = new View(this);
        divider.setBackgroundColor(LINE);
        pageContent.addView(divider, bottomSpace(dp(18), dp(1)));
        for (String paragraph : article.body.split("\n\n")) {
            if (paragraph.trim().isEmpty()) continue;
            TextView body = text(paragraph, 16, INK, false);
            body.setLineSpacing(dp(5), 1.08f);
            pageContent.addView(body, bottomSpace(dp(16)));
        }
        Button save = smallButton(isSaved(article) ? "Tersimpan ✓" : "Simpan berita  +", WHITE, ACCENT);
        save.setBackground(background(WHITE, LINE, 1, 12));
        save.setOnClickListener(view -> toggleSaved(article));
        pageContent.addView(save, bottomSpace(dp(24)));
    }

    private View articleRow(Article article, boolean featured) {
        // Buat satu baris berita yang dapat dibuka, dengan tombol simpan terpisah.
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        card.setBackground(background(WHITE, LINE, 1, 12));
        card.setClickable(true);
        card.setFocusable(true);

        if (!article.imageUrl.isEmpty()) {
            ImageView image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            card.addView(image, bottomSpace(dp(13), dp(featured ? 190 : 145)));
            loadImage(article.imageUrl, image);
        }

        LinearLayout meta = new LinearLayout(this);
        meta.setGravity(Gravity.CENTER_VERTICAL);
        TextView category = text(article.category.toUpperCase(), 11, ACCENT, true);
        category.setLetterSpacing(0.08f);
        meta.addView(category, new LinearLayout.LayoutParams(0, -2, 1));
        TextView date = text(article.dateLabel, 11, MUTED, false);
        meta.addView(date);
        card.addView(meta, bottomSpace(dp(9)));

        TextView title = text(article.title, featured ? 21 : 18, INK, true);
        card.addView(title, bottomSpace(dp(8)));
        TextView summary = text(article.summary, 14, MUTED, false);
        summary.setMaxLines(3);
        card.addView(summary, bottomSpace(dp(12)));

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView author = text(article.author, 12, MUTED, false);
        footer.addView(author, new LinearLayout.LayoutParams(0, -2, 1));
        Button bookmark = smallButton(isSaved(article) ? "✓" : "+", WHITE, ACCENT);
        bookmark.setMinWidth(dp(40));
        bookmark.setOnClickListener(view -> toggleSaved(article));
        footer.addView(bookmark);
        card.addView(footer);

        card.setOnClickListener(view -> {
            selectedArticle = article;
            currentScreen = "detail";
            renderShell();
        });
        LinearLayout.LayoutParams params = bottomSpace(dp(12));
        return card;
    }

    private void addSectionTitle(String title, String eyebrow) {
        // Komponen judul bersama agar hirarki teks konsisten pada setiap halaman.
        TextView label = text(eyebrow, 11, MUTED, true);
        label.setLetterSpacing(0.1f);
        pageContent.addView(label, bottomSpace(dp(5)));
        TextView heading = text(title, 25, INK, true);
        pageContent.addView(heading, bottomSpace(dp(14)));
    }

    private void addMessage(String message) {
        // Tampilkan status kosong, memuat, atau gagal di dalam area konten.
        TextView view = text(message, 15, MUTED, false);
        view.setPadding(dp(16), dp(18), dp(16), dp(18));
        view.setBackground(background(WHITE, LINE, 1, 12));
        pageContent.addView(view, bottomSpace(dp(12)));
    }

    private List<Article> visibleArticles() {
        // Batasi cache lokal ke kategori aktif; pencarian sudah difilter oleh API server.
        List<Article> visible = new ArrayList<>();
        for (Article article : articles) {
            boolean matchesCategory = !currentScreen.equals("category")
                    || article.categorySlug.equals(activeCategory);
                if (matchesCategory) visible.add(article);
        }
        return visible;
    }

    private void openCategory(Category category) {
        // Simpan kategori pilihan sebagai state dan minta ulang daftar dari server.
        activeCategory = category.slug;
        currentScreen = "category";
        currentQuery = "";
        loadArticles();
        renderShell();
    }

    private void submitSearch() {
        // Ambil teks kolom pencarian dan pindah ke layar hasil pencarian.
        currentQuery = searchInput.getText().toString().trim();
        activeCategory = "";
        currentScreen = "search";
        loadArticles();
        renderShell();
    }

    private void loadCategories() {
        // Ambil kategori di worker thread, parse JSON, lalu perbarui UI di main thread.
        executor.execute(() -> {
            try {
                JSONArray response = new JSONArray(request("/categories/"));
                List<Category> loaded = new ArrayList<>();
                for (int index = 0; index < response.length(); index++) {
                    JSONObject item = response.getJSONObject(index);
                    loaded.add(new Category(item.optString("name"), item.optString("slug"),
                            item.optInt("article_count")));
                }
                mainHandler.post(() -> {
                    categories.clear();
                    categories.addAll(loaded);
                    renderPage();
                });
            } catch (Exception ignored) {
                mainHandler.post(this::renderPage);
            }
        });
    }

    private void loadArticles() {
        // Susun query dari state halaman dan minta maksimal 100 artikel dari API.
        loading = true;
        loadError = "";
        renderPage();
        String category = currentScreen.equals("category") ? activeCategory : "";
        String query = currentQuery;
        // Jaringan berjalan di worker thread agar antarmuka utama tetap responsif.
        executor.execute(() -> {
            try {
                StringBuilder path = new StringBuilder("/articles/");
                List<String> parameters = new ArrayList<>();
                if (!category.isEmpty()) parameters.add("category=" + encode(category));
                if (!query.isEmpty()) parameters.add("search=" + encode(query));
                if (!parameters.isEmpty()) {
                    path.append("?");
                    for (int parameterIndex = 0; parameterIndex < parameters.size(); parameterIndex++) {
                        if (parameterIndex > 0) path.append("&");
                        path.append(parameters.get(parameterIndex));
                    }
                }
                JSONArray response = new JSONArray(request(path.toString()));
                List<Article> loaded = new ArrayList<>();
                for (int index = 0; index < response.length(); index++) {
                    loaded.add(Article.fromJson(response.getJSONObject(index)));
                }
                mainHandler.post(() -> {
                    articles.clear();
                    articles.addAll(loaded);
                    loading = false;
                    renderPage();
                });
            } catch (Exception error) {
                mainHandler.post(() -> {
                    loading = false;
                    loadError = "Tidak dapat terhubung ke server.";
                    renderPage();
                });
            }
        });
    }

    private String request(String path) throws Exception {
        // Jalankan GET HTTP dan kembalikan body respons sebagai teks JSON.
        HttpURLConnection connection = (HttpURLConnection) new URL(API_BASE + path).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        try {
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream();
            if (status < 200 || status >= 300) throw new IllegalStateException("HTTP " + status);
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) result.append(line);
            reader.close();
            return result.toString();
        } finally {
            connection.disconnect();
        }
    }

    private void loadImage(String imageUrl, ImageView target) {
        // Unduh dan dekode gambar di latar; Bitmap baru dipasang pada ImageView di main thread.
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(imageUrl).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(8000);
                try (InputStream stream = connection.getInputStream()) {
                    Bitmap bitmap = BitmapFactory.decodeStream(stream);
                    if (bitmap != null) mainHandler.post(() -> target.setImageBitmap(bitmap));
                }
            } catch (Exception ignored) {
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void saveImageLocally(Article article) {
        // Salin gambar dari server ke galeri modern atau folder privat Android versi lama.
        executor.execute(() -> {
            HttpURLConnection connection = null;
            Uri savedUri = null;
            try {
                connection = (HttpURLConnection) new URL(article.imageUrl).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(15000);
                int status = connection.getResponseCode();
                if (status < 200 || status >= 300) throw new IllegalStateException("Unduhan gambar gagal");

                String mimeType = connection.getContentType();
                if (mimeType == null || !mimeType.startsWith("image/")) mimeType = "image/jpeg";
                try (InputStream input = connection.getInputStream()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        // MediaStore menaruh gambar di galeri tanpa izin storage luas pada Android 10+.
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Images.Media.DISPLAY_NAME, article.slug + imageExtension(mimeType));
                        values.put(MediaStore.Images.Media.MIME_TYPE, mimeType);
                        values.put(MediaStore.Images.Media.RELATIVE_PATH,
                                Environment.DIRECTORY_PICTURES + "/KabarKita");
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);
                        savedUri = getContentResolver().insert(
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                        if (savedUri == null) throw new IllegalStateException("Tidak dapat membuat berkas gambar");
                        try (OutputStream output = getContentResolver().openOutputStream(savedUri)) {
                            if (output == null) throw new IllegalStateException("Tidak dapat menulis gambar");
                            copy(input, output);
                        }
                        values.clear();
                        // File baru terlihat aplikasi lain setelah proses salin selesai.
                        values.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(savedUri, values, null, null);
                    } else {
                        File externalPictures = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                        if (externalPictures == null) throw new IllegalStateException("Penyimpanan tidak tersedia");
                        File folder = new File(externalPictures, "KabarKita");
                        if (!folder.exists() && !folder.mkdirs()) {
                            throw new IllegalStateException("Tidak dapat membuat folder gambar");
                        }
                        File imageFile = new File(folder, article.slug + imageExtension(mimeType));
                        try (OutputStream output = new FileOutputStream(imageFile)) {
                            copy(input, output);
                        }
                    }
                }
                mainHandler.post(() -> Toast.makeText(this,
                        "Gambar disimpan ke Pictures/KabarKita", Toast.LENGTH_LONG).show());
            } catch (Exception error) {
                if (savedUri != null) getContentResolver().delete(savedUri, null, null);
                mainHandler.post(() -> Toast.makeText(this,
                        "Gambar gagal disimpan. Periksa koneksi server.", Toast.LENGTH_LONG).show());
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void copy(InputStream input, OutputStream output) throws Exception {
        // Salin data bertahap agar ukuran gambar tidak perlu ditampung seluruhnya di memori.
        byte[] buffer = new byte[8192];
        int count;
        while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
        output.flush();
    }

    private String imageExtension(String mimeType) {
        // Pilih ekstensi file yang sesuai dengan tipe konten dari server.
        if (mimeType.equalsIgnoreCase("image/png")) return ".png";
        if (mimeType.equalsIgnoreCase("image/webp")) return ".webp";
        return ".jpg";
    }

    private void toggleSaved(Article article) {
        // SharedPreferences menyimpan kumpulan slug agar pilihan tetap ada setelah aplikasi ditutup.
        SharedPreferences preferences = getSharedPreferences("saved_articles", MODE_PRIVATE);
        Set<String> saved = new HashSet<>(preferences.getStringSet("slugs", new HashSet<>()));
        if (saved.contains(article.slug)) {
            saved.remove(article.slug);
            Toast.makeText(this, "Dihapus dari Tersimpan", Toast.LENGTH_SHORT).show();
        } else {
            saved.add(article.slug);
            Toast.makeText(this, "Berita disimpan", Toast.LENGTH_SHORT).show();
        }
        preferences.edit().putStringSet("slugs", saved).apply();
        renderPage();
    }

    private Set<String> savedSlugs() {
        // Baca salinan set tersimpan agar perubahan berikutnya tidak mengubah objek preferensi langsung.
        return new HashSet<>(getSharedPreferences("saved_articles", MODE_PRIVATE)
                .getStringSet("slugs", new HashSet<>()));
    }

    private boolean isSaved(Article article) {
        // Slug unik menjadi kunci untuk mengetahui status simpan sebuah berita.
        return savedSlugs().contains(article.slug);
    }

    private Button smallButton(String label, int backgroundColor, int textColor) {
        // Factory sederhana untuk menjaga ukuran dan gaya tombol aplikasi seragam.
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(13);
        button.setAllCaps(false);
        button.setTextColor(textColor);
        button.setPadding(dp(12), 0, dp(12), 0);
        button.setMinHeight(dp(38));
        button.setBackground(background(backgroundColor, backgroundColor, 0, 10));
        return button;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        // Buat TextView dengan gaya umum tanpa mengulang pengaturan di setiap layar.
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable background(int color, int stroke, int strokeWidth, int radius) {
        // Hasilkan drawable berbentuk rounded rectangle untuk latar komponen UI.
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        if (strokeWidth > 0) drawable.setStroke(dp(strokeWidth), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams bottomSpace(int margin) {
        // LayoutParams untuk komponen setinggi konten dengan jarak di bawahnya.
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = margin;
        return params;
    }

    private LinearLayout.LayoutParams bottomSpace(int margin, int height) {
        // Overload ketika komponen memerlukan tinggi tetap, misalnya area gambar.
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, height);
        params.bottomMargin = margin;
        return params;
    }

    private int dp(int value) {
        // Konversi satuan dp desain ke piksel sesuai kepadatan layar perangkat.
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private String encode(String value) throws Exception {
        // Escape teks query agar aman dipakai sebagai nilai parameter URL.
        return URLEncoder.encode(value, "UTF-8");
    }

    // Objek data ringan untuk satu kategori yang dibaca dari respons API.
    private static final class Category {
        final String name;
        final String slug;
        final int articleCount;

        Category(String name, String slug, int articleCount) {
            // Simpan field JSON yang dipakai pada chip dan daftar topik.
            this.name = name;
            this.slug = slug;
            this.articleCount = articleCount;
        }
    }

    // Objek data satu berita, termasuk URL gambar untuk tampilan dan unduhan lokal.
    private static final class Article {
        final String title;
        final String slug;
        final String summary;
        final String body;
        final String author;
        final String category;
        final String categorySlug;
        final String dateLabel;
        final String imageUrl;

        Article(String title, String slug, String summary, String body, String author,
            String category, String categorySlug, String dateLabel, String imageUrl) {
            // Constructor memindahkan nilai hasil parse JSON ke model yang dipakai UI.
            this.title = title;
            this.slug = slug;
            this.summary = summary;
            this.body = body;
            this.author = author;
            this.category = category;
            this.categorySlug = categorySlug;
            this.dateLabel = dateLabel;
                this.imageUrl = imageUrl;
        }

        static Article fromJson(JSONObject item) {
                // Parser ini menjaga kontrak JSON API selaras dengan objek yang dipakai layar.
            return new Article(item.optString("title"), item.optString("slug"),
                    item.optString("summary"), item.optString("body"), item.optString("author"),
                    item.optString("category"), item.optString("category_slug"),
                    item.optString("created_at").replace("T", " ").replace("Z", ""),
                    item.optString("image_url"));
        }
    }
}