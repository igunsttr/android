# Pertemuan 10: Jaringan asinkron dan penanganan error

Folder ini merupakan proyek Android Studio dan Django mandiri untuk pertemuan 10.

## Menjalankan server Django

Dari folder proyek, jalankan PowerShell:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
cd server
py manage.py migrate
py manage.py seed_news
py manage.py runserver 0.0.0.0:8000
```

## Menjalankan Android

Buka folder proyek di Android Studio, tunggu Gradle Sync, jalankan server di atas, lalu jalankan modul `app` pada emulator. Emulator Android menggunakan `10.0.2.2` untuk mengakses komputer host. Untuk perangkat fisik, ubah konstanta API pada `MainActivity.java` menjadi IP LAN komputer dan sesuaikan `ALLOWED_HOSTS` di `server/config/settings.py`.

Materi pertemuan: lihat `../docs/pertemuan-10.docx`. Contoh server menyediakan Django Admin, API berita/kategori, dan data latihan. Proyek lokal memakai HTTP dan `DEBUG=True`; jangan gunakan konfigurasi ini untuk deployment publik.
