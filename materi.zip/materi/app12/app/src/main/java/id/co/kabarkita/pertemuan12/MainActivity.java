package id.co.kabarkita.pertemuan12;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle state) { super.onCreate(state); WebView web = new WebView(this); web.setWebViewClient(new WebViewClient()); setContentView(web); web.loadUrl("http://10.0.2.2:8000/"); }
}
