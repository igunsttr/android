from django.shortcuts import render
from django.db.models import Q
from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import Article, Category
from .serializers import ArticleSerializer, CategorySerializer


@api_view(["GET"])
def categories(request):
    """Kirim semua kategori beserta jumlah berita di setiap kategori."""
    items = Category.objects.all().prefetch_related("articles")
    return Response(CategorySerializer(items, many=True).data)


@api_view(["GET"])
def articles(request):
    """Kirim daftar berita; query parameter dapat membatasi kategori atau kata."""
    items = Article.objects.select_related("category")
    category_slug = request.query_params.get("category")
    search = request.query_params.get("search", "").strip()

    # Filter diterapkan ke queryset sebelum objek dikonversi menjadi JSON.
    if category_slug:
        items = items.filter(category__slug=category_slug)
    if search:
        items = items.filter(
            Q(title__icontains=search)
            | Q(summary__icontains=search)
            | Q(body__icontains=search)
            | Q(category__name__icontains=search)
        )
    return Response(
        ArticleSerializer(items[:100], many=True, context={"request": request}).data
    )


@api_view(["GET"])
def article_detail(request, slug):
    """Cari berita berdasarkan slug, lalu kirim 404 jika berita tidak ada."""
    item = get_object_or_404(Article.objects.select_related("category"), slug=slug)
    return Response(ArticleSerializer(item, context={"request": request}).data)

def lesson_home(request):
    """Render daftar berita Django untuk contoh WebView server-rendered."""
    items = Article.objects.select_related("category")[:20]
    return render(request, "news/lesson_home.html", {"articles": items})
