from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from news.views import lesson_home


# URL admin untuk mengelola konten dan awalan /api/ untuk endpoint berita.
urlpatterns = [
    path("", lesson_home, name="lesson-home"),
    path("admin/", admin.site.urls),
    path("api/", include("news.urls")),
]

if settings.DEBUG:
    # Hanya server lokal yang menyajikan unggahan media langsung lewat Django.
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)