package id.co.kabarkita.pertemuan07;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final String API = "http://10.0.2.2:8000/api/";
    private LinearLayout panel;
    private TextView result;
    private int lesson;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        lesson = 7;
        ScrollView scroll = new ScrollView(this);
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        panel.setPadding(pad, pad, pad, pad);
        scroll.addView(panel);
        setContentView(scroll);
        addText("Pertemuan 7: Penyimpanan lokal dengan Preferences", 24, true);
        addText("Contoh belajar Android native Java + server Django. Jalankan server dahulu untuk fitur API.", 16, false);
        result = addText("Siap. Ikuti latihan, lalu amati hasilnya di layar.", 15, false);
        showLesson();
    }

    private void showLesson() {
        if (lesson == 3) {
            addText("LinearLayout menyusun elemen berurutan. Padding memberi ruang di dalam komponen; margin memberi jarak antarkomponen.", 16, false);
            addButton("Ubah tampilan", v -> { result.setText("Tombol merespons klik; teks diperbarui di main thread."); result.setTextColor(0xff1565c0); });
        } else if (lesson == 4) {
            addText("Pilih berita untuk membuka layar detail melalui Intent eksplisit.", 16, false);
            addButton("Buka detail berita", v -> startActivity(new Intent(this, DetailActivity.class)));
        } else if (lesson == 5) {
            EditText weight = input("Berat badan (kg)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            EditText height = input("Tinggi badan (cm)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            addButton("Hitung BMI", v -> {
                try {
                    double kg = Double.parseDouble(weight.getText().toString().trim());
                    double cm = Double.parseDouble(height.getText().toString().trim());
                    if (kg <= 0 || cm <= 0) throw new NumberFormatException();
                    double bmi = kg / Math.pow(cm / 100.0, 2);
                    result.setText(String.format(java.util.Locale.US, "BMI: %.1f. Hasil ini hanya latihan menghitung, bukan diagnosis kesehatan.", bmi));
                } catch (NumberFormatException e) { result.setText("Masukkan berat dan tinggi berupa angka lebih dari 0."); }
            });
        } else if (lesson == 6) {
            addText("ListView menampilkan data dari adapter. Tombol memuat judul berita melalui Django API di thread latar belakang.", 16, false);
            ArrayList<String> rows = new ArrayList<>();
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rows);
            ListView list = new ListView(this);
            list.setAdapter(adapter);
            panel.addView(list, new LinearLayout.LayoutParams(-1, dp(300)));
            addButton("Muat daftar berita", v -> {
                result.setText("Memuat berita...");
                request("articles/", new Callback() {
                    public void success(String body) {
                        try { JSONArray data = new JSONArray(body); adapter.clear();
                            for (int i = 0; i < data.length(); i++) adapter.add(data.getJSONObject(i).optString("title", "Tanpa judul"));
                            result.setText("Berhasil memuat " + data.length() + " berita.");
                        } catch (Exception e) { result.setText("Respons API tidak dapat dibaca sebagai daftar JSON."); }
                    }
                    public void failure(String error) { result.setText(error); }
                });
            });
        } else if (lesson == 7) {
            addText("SharedPreferences cocok untuk preferensi kecil seperti berita favorit. Data tersimpan lokal pada perangkat.", 16, false);
            EditText favorite = input("Slug berita favorit", InputType.TYPE_CLASS_TEXT);
            SharedPreferences prefs = getSharedPreferences("lesson_favorites", MODE_PRIVATE);
            favorite.setText(prefs.getString("favorite_slug", ""));
            addButton("Simpan favorit", v -> {
                String slug = favorite.getText().toString().trim();
                if (slug.isEmpty()) { result.setText("Slug tidak boleh kosong."); return; }
                prefs.edit().putString("favorite_slug", slug).apply();
                result.setText("Favorit tersimpan di perangkat: " + slug);
            });
        } else if (lesson == 8) {
            addText("Server Django memiliki model Category dan Article di server/news/models.py. Field model menjadi kolom database setelah migration.", 16, false);
            addText("Article: title, slug, summary, body, author, image, category, created_at", 15, true);
            addText("Praktik di terminal folder server: py manage.py makemigrations ? py manage.py migrate ? py manage.py showmigrations", 15, false);
            addButton("Uji API setelah migration", v -> { result.setText("Memeriksa endpoint Django..."); request("articles/", new Callback() { public void success(String body) { result.setText("API merespons. Contoh JSON: " + body.substring(0, Math.min(160, body.length()))); } public void failure(String error) { result.setText(error); } }); });
        } else if (lesson == 9) {
            addText("REST API memberi kontrak JSON antara Android dan Django. Endpoint kategori mengirim array objek kategori.", 16, false);
            addButton("Ambil kategori", v -> { result.setText("Memuat kategori..."); request("categories/", new Callback() {
                public void success(String body) { try { JSONArray data = new JSONArray(body); StringBuilder names = new StringBuilder(); for (int i=0;i<data.length();i++) { JSONObject item=data.getJSONObject(i); if (i>0) names.append("\n"); names.append(item.optString("name")).append(" (artikel: ").append(item.optInt("article_count")).append(")"); } result.setText(data.length()==0 ? "Belum ada kategori." : names.toString()); } catch (Exception e) { result.setText("JSON kategori tidak valid."); } }
                public void failure(String error) { result.setText(error); }
            }); });
        } else if (lesson == 10) {
            addText("Jaringan tidak boleh berjalan di main thread. Aplikasi menunjukkan status memuat, sukses, atau error dan menyediakan tombol coba lagi.", 16, false);
            addButton("Muat / coba lagi", v -> { result.setText("Status: memuat..."); request("articles/", new Callback() { public void success(String body) { result.setText("Status: berhasil. Server mengirim " + body.length() + " karakter JSON."); } public void failure(String error) { result.setText("Status: gagal. " + error + "\nPeriksa server, URL, jaringan, lalu coba lagi."); } }); });
        }
    }

    private TextView addText(String value, int size, boolean bold) {
        TextView view = new TextView(this); view.setText(value); view.setTextSize(size); view.setTextColor(0xff263238);
        if (bold) view.setTypeface(null, android.graphics.Typeface.BOLD);
        view.setPadding(0, dp(8), 0, dp(8)); panel.addView(view); return view;
    }
    private EditText input(String hint, int type) { EditText field = new EditText(this); field.setHint(hint); field.setInputType(type); panel.addView(field, new LinearLayout.LayoutParams(-1, -2)); return field; }
    private void addButton(String label, View.OnClickListener listener) { Button button = new Button(this); button.setText(label); button.setOnClickListener(listener); panel.addView(button); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private interface Callback { void success(String body); void failure(String error); }

    private void request(String path, Callback callback) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(API + path).openConnection();
                connection.setConnectTimeout(5000); connection.setReadTimeout(5000); connection.setRequestMethod("GET");
                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) { String line; while ((line = reader.readLine()) != null) body.append(line); }
                String response = body.toString();
                if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + response);
                runOnUiThread(() -> callback.success(response));
            } catch (Exception e) { String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage(); runOnUiThread(() -> callback.failure(message)); }
            finally { if (connection != null) connection.disconnect(); }
        }).start();
    }
}
