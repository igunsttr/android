# berita/views.py

from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Berita
from .serializers import BeritaSerializer

@api_view(['GET'])
def daftar_berita(request):
    """
    Mengambil semua data berita terbaru
    """
    # Ambil 10 berita terbaru
    beritas = Berita.objects.all()[:10]
    
    # Serialisasi data
    serializer = BeritaSerializer(beritas, many=True)
    
    # Kirim respons JSON
    return Response(serializer.data)

@api_view(['GET'])
def detail_berita(request, slug):
    """
    Mengambil detail satu berita berdasarkan slug
    """
    try:
        berita = Berita.objects.get(slug=slug)
    except Berita.DoesNotExist:
        return Response(status=404)
        
    serializer = BeritaSerializer(berita)
    return Response(serializer.data)