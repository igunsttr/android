# berita/serializers.py

from rest_framework import serializers
from .models import Berita

class BeritaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Berita
        # Tentukan field mana saja yang akan dikirim ke aplikasi mobile
        fields = ['id', 'judul', 'konten', 'tanggal_publikasi', 'gambar_url', 'slug']