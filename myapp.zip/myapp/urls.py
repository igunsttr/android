# project_name/urls.py

from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    # Definisikan base API URL untuk aplikasi mobile
    path('api/v1/', include('berita.urls')), 
    path('berita/', views.daftar_berita, name='daftar_berita'),
    
    # Endpoint untuk detail berita
    # Contoh: GET /api/v1/berita/judul-berita-pertama/
    path('berita/<slug:slug>/', views.detail_berita, name='detail_berita'),
]