# berita/serializers.py
# berita/models.py

from django.db import models

class Berita(models.Model):
    judul = models.CharField(max_length=255)
    konten = models.TextField()
    tanggal_publikasi = models.DateTimeField(auto_now_add=True)
    gambar_url = models.URLField(blank=True, null=True)
    slug = models.SlugField(unique=True)

    def __str__(self):
        return self.judul

    class Meta:
        ordering = ['-tanggal_publikasi']
        